import 'package:flutter/material.dart';

class AppColors {
  static const primaryColor = Color(0xFF212224);
  static const secondaryColor = Color(0xFF317AF7);
  static const secondary2Color = Color(0xFF26282D);
}
